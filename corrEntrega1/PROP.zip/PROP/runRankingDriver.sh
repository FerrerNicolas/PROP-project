#!/bin/bash
java -cp ".:./src/:./tests" domini.Ranking.DriverRanking
