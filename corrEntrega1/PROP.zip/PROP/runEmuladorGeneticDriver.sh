#!/bin/bash
java -cp ".:./src/:./tests" domini.EmuladorGenetic.EmuladorGenetic
