#!/bin/bash
java -cp ".:./src/:./tests" domini.Tuple.DriverTuple
