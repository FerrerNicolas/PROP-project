#!/bin/bash
java -cp ".:./src/:./tests" domini.GlobalRecords.DriverGlobalRecords
