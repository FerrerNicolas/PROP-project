#!/bin/bash
java -cp ".:./src/:./tests" domini.Board.DriverBoard
