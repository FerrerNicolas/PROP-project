package model;
//Victor
public enum Diff {
	EASY,
	NORMAL,
	HARD
}
