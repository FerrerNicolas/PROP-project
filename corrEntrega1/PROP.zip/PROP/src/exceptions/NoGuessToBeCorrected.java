package exceptions;

public class NoGuessToBeCorrected extends Exception {
	public NoGuessToBeCorrected() {
		super();
	}
	public NoGuessToBeCorrected(String msg) {
		super(msg);
	}
}
