package exceptions;

public class CodeOrCorrectionNull extends Exception {
	public CodeOrCorrectionNull() {
		super();
	}
	public CodeOrCorrectionNull(String msg) {
		super(msg);
	}
}