#!/bin/bash
java -cp ".:./src/:./tests" domini.Code.DriverCode
