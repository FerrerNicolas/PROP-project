#!/bin/bash
java -cp ".:./src/:./tests" domini.Correction.DriverCorrection
