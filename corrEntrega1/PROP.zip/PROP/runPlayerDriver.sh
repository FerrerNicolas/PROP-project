#!/bin/bash
java -cp ".:./src/:./tests" domini.Player.DriverPlayer
