package domini.Ai;
import java.util.*;
import exceptions.*;
import model.Code;
import model.Game;
import model.Correction;

//Victor
public class FiveGuess extends Ai {	 //THIS IS A STUB FOR TESTS
	public FiveGuess(Game g) {
		super(g);
	}
	
	public Code codeBreakerTurn(Code code, Correction correction) throws CodeOrCorrectionNull, CodeAlreadyUsed {
		if (false) throw (new CodeOrCorrectionNull());
		if (false) throw (new CodeAlreadyUsed());
		return new Code();
	}
	
}
