package domini.Board;

public class Game {
	
	public Game() {}
	public Boolean codeIsValid(Code c) {
		return true;
	}
}
